# Context-Aware PPG Artifact Separation and Reference-State Normalization

> **Research track 2:** Separate measurement interference from
> context-dependent physiological variation, then investigate whether
> selected PPG characteristics can be estimated under a clearly defined
> reference condition.

[![Research
status](https://img.shields.io/badge/status-research%20framework-blue)]()
[![Focus](https://img.shields.io/badge/focus-artifact%20separation%20%2B%20normalization-6f42c1)]()
[![Scope](https://img.shields.io/badge/scope-counterfactual%20estimation-orange)]()

## Table of contents

-   [1. Project overview](#1-project-overview)
-   [2. The two interpretations of a standardized
    PPG](#2-the-two-interpretations-of-a-standardized-ppg)
-   [3. Research question and scope](#3-research-question-and-scope)
-   [4. The central scientific
    distinction](#4-the-central-scientific-distinction)
-   [5. Conceptual signal model](#5-conceptual-signal-model)
-   [6. Why an exact pure PPG is generally not
    identifiable](#6-why-an-exact-pure-ppg-is-generally-not-identifiable)
-   [7. Reference condition: define the target
    precisely](#7-reference-condition-define-the-target-precisely)
-   [8. Proposed two-branch research
    architecture](#8-proposed-two-branch-research-architecture)
-   [9. Sensor fusion and covariates](#9-sensor-fusion-and-covariates)
-   [10. Data and experimental design](#10-data-and-experimental-design)
-   [11. Modeling approaches](#11-modeling-approaches)
-   [12. Training targets and loss
    functions](#12-training-targets-and-loss-functions)
-   [13. Validation strategy](#13-validation-strategy)
-   [14. Recommended experiments](#14-recommended-experiments)
-   [15. Datasets and resources](#15-datasets-and-resources)
-   [16. Limitations and threats to
    validity](#16-limitations-and-threats-to-validity)
-   [17. Suggested implementation
    plan](#17-suggested-implementation-plan)
-   [18. Suggested repository
    structure](#18-suggested-repository-structure)
-   [19. Research papers and reading
    list](#19-research-papers-and-reading-list)
-   [20. Reporting checklist](#20-reporting-checklist)
-   [21. Glossary](#21-glossary)
-   [22. Research boundaries and safety
    note](#22-research-boundaries-and-safety-note)

------------------------------------------------------------------------

## 1. Project overview

Wearable photoplethysmography (PPG) is affected by both measurement
interference and genuine physiological variation. During walking, for
example, wrist movement can distort the optical measurement while
exercise simultaneously changes heart rate, vascular tone, respiration,
and peripheral perfusion.

These effects must not be treated as one undifferentiated noise source.

This research track investigates two related but distinct tasks:

1.  **Measurement-artifact correction:** Estimate a cleaner
    representation of the PPG measurement by reducing interference such
    as motion artifact, sensor displacement, ambient light, and unstable
    contact.
2.  **Reference-state physiological normalization:** Estimate what
    selected PPG features (or, in a more ambitious experiment, a
    waveform representation) would be expected under a specified
    reference condition, given the observed data and explicit modeling
    assumptions.

The first task is a signal-quality and reconstruction problem. The
second is a conditional prediction/counterfactual problem. The second
cannot be validated merely by showing that the output looks smoother.

### Central objective

Develop a multimodal framework that:

-   Separates measurement artifacts from genuine physiological responses
    as far as the available sensors and experimental design allow.
-   Uses context and physiological covariates to explain observed PPG
    variation.
-   Defines a reference condition precisely.
-   Estimates reference-condition PPG features with uncertainty.
-   Validates the estimates using repeated controlled measurements and
    independent physiological references.

### What this project is --- and is not

**This project is:**

-   Multimodal PPG signal-quality enhancement.
-   Context-aware physiological modeling.
-   Reference-condition feature estimation.
-   A framework for testing counterfactual or standardized
    representations.

**This project is not:**

-   A claim that all activity-related PPG changes are noise.
-   A guarantee that an exact unobserved waveform can be recovered.
-   A claim that sleeping PPG is a universal ground truth.
-   A medical diagnostic system.
-   A substitute for ECG or clinical reference measurements.

------------------------------------------------------------------------

## 2. The two interpretations of a standardized PPG

The phrase "pure PPG" can refer to two different targets. They must be
studied separately.

### Interpretation A --- Remove measurement interference

The target is a better estimate of the PPG that the sensor would have
measured without avoidable measurement artifacts, while retaining
genuine physiological changes.

Examples of unwanted interference:

-   Wrist or finger motion that changes optical coupling.
-   Sensor displacement.
-   Ambient light leakage.
-   Electronic noise and clipping.
-   Unstable contact or strap pressure artifacts.

If walking raises the person's true heart rate, the corrected PPG should
still reflect that higher rate. Artifact removal should not erase
exercise physiology.

### Interpretation B --- Estimate a reference-condition representation

The target is not simply a cleaner measurement. It is an estimate of
what selected PPG characteristics might have been under a defined
condition, such as awake supine rest.

Examples:

-   Estimate reference-state pulse amplitude.
-   Estimate reference-state pulse width or rise time.
-   Estimate a reference-state feature vector.
-   In a later and more difficult stage, estimate a reference-condition
    waveform.

This is a counterfactual-style prediction: the person was observed in
one condition, but the model estimates an outcome under another
condition.

### Comparison

  -----------------------------------------------------------------------
  Question                Interpretation A        Interpretation B
  ----------------------- ----------------------- -----------------------
  Main target             Artifact-reduced        PPG features under a
                          observed PPG            defined reference
                                                  condition

  Removes motion          Yes, where identifiable Requires a separate
  interference?                                   artifact stage

  Removes true exercise   No                      May standardize
  heart-rate response?                            selected targets, but
                                                  must state what is
                                                  removed

  Needs activity/posture  Helpful                 Essential or strongly
  labels?                                         recommended

  Needs                   Helpful for validation  Crucial for credible
  reference-condition                             validation
  data?                                           

  Can be validated        For pulse timing/HR,    ECG helps, but cannot
  against ECG?            with caveats            by itself validate all
                                                  PPG morphology

  Main scientific         Distinguish artifact    Counterfactual
  challenge               from pulse              identifiability and
                                                  confounding
  -----------------------------------------------------------------------

**Recommended design:** implement and evaluate Interpretation A first.
Then use the corrected measurements as inputs to Interpretation B. Never
merge both objectives into a single unexplained "cleaning" score.

------------------------------------------------------------------------

## 3. Research question and scope

### Primary research question

> Can synchronized PPG and contextual physiological signals be used to
> distinguish measurement artifacts from genuine context-dependent
> physiological variation, and can selected PPG features then be
> estimated under a defined reference condition?

### Sub-questions

1.  How much motion-related PPG corruption can be detected or corrected
    using accelerometer and gyroscope signals?
2.  Does temperature explain additional PPG morphology variation after
    accounting for activity and posture?
3.  How do posture, respiration, and cardiovascular state relate to PPG
    features?
4.  Which features can be estimated reliably under a reference
    condition?
5.  What additional assumptions and controlled observations are needed
    for counterfactual estimation?
6.  Does reference-state feature estimation improve longitudinal
    comparability without suppressing meaningful physiological
    information?
7.  How should uncertainty and unsupported contexts be reported?

### Scope boundaries

The research should make two separate claims, if supported:

-   **Claim A:** The method improves measurement quality or
    pulse-related estimation under motion.
-   **Claim B:** The method estimates selected features under a
    specified reference condition with a measured prediction error and
    uncertainty.

Do not infer Claim B from evidence supporting Claim A.

------------------------------------------------------------------------

## 4. The central scientific distinction

### Genuine physiology versus measurement artifact

  -----------------------------------------------------------------------
  Source                  Example                 Should artifact
                                                  correction remove it?
  ----------------------- ----------------------- -----------------------
  Wrist movement          Sensor moves relative   Reduce if identifiable
                          to skin                 

  Sensor displacement     Watch shifts            Detect/flag; correction
                                                  may be unreliable

  Ambient light           External light reaches  Reduce if identifiable
                          detector                

  Contact pressure        Strap tightness changes Model/flag; not always
                          optical coupling and    separable
                          local perfusion         

  Exercise heart-rate     Heart rate increases    No
  response                during running          

  Postural cardiovascular Standing changes        No
  response                hemodynamics            

  Cold-induced            Peripheral perfusion    No
  vasoconstriction        changes                 

  Respiratory modulation  Pulse                   No
                          amplitude/interval      
                          varies with breathing   

  Stress response         Sympathetic activity    No
                          alters circulation      
  -----------------------------------------------------------------------

The key rule is:

> A signal component correlated with movement is not automatically a
> motion artifact. Movement and genuine cardiovascular responses can
> occur at the same time.

### Two different outputs

![Two output types: artifact-corrected signal and reference-state
estimate](assets/two_outputs.svg)

-   **Output A:** best estimate of the observed physiological pulse
    waveform after reducing measurement interference.
-   **Output B:** an estimate of selected features under a hypothetical
    reference condition.

Output B is not necessarily a physically observed waveform. It should be
labeled as an estimate and accompanied by uncertainty.

------------------------------------------------------------------------

## 5. Conceptual signal model

A simple additive model is useful for explaining the idea:

\[ P\_{`\mathrm{obs}`{=tex}}(t) = P\_{`\mathrm{phys}`{=tex}}(t) +
N\_{`\mathrm{motion}`{=tex}}(t) + N\_{`\mathrm{sensor}`{=tex}}(t) +
`\epsilon`{=tex}(t) \]

This is only an approximation. Real optical measurements are nonlinear
and artifacts can interact with the pulse waveform.

A more general model is:

\[ P\_{`\mathrm{obs}`{=tex}}(t) = F`\left`{=tex}( H(t), A(t), S(t),
T(t), R(t), C(t), D `\right`{=tex}) +`\epsilon`{=tex}(t) \]

where:

-   (H(t)): cardiovascular and autonomic state.
-   (A(t)): activity and movement.
-   (S(t)): posture and sensor height.
-   (T(t)): skin/peripheral temperature.
-   (R(t)): respiration.
-   (C(t)): sensor contact and coupling.
-   (D): device characteristics.
-   (`\epsilon`{=tex}(t)): unexplained noise.

A useful conceptual decomposition is:

\[ P\_{`\mathrm{obs}`{=tex}} = P\_{`\mathrm{phys,context}`{=tex}} +
N\_{`\mathrm{measurement}`{=tex}} + `\epsilon`{=tex} \]

But (P\_{`\mathrm{phys,context}`{=tex}}) itself contains both the
baseline physiology and real context-dependent changes. It should not be
assumed that these are independently observable from one PPG channel.

### Stage A: artifact correction

\[ `\hat `{=tex}P\_{`\mathrm{clean}`{=tex}} =
g\_`\theta`{=tex}(P\_{`\mathrm{obs}`{=tex}}, ACC, GYRO, Q) \]

where (Q) may include sensor quality/contact information.

The intended output preserves true cardiac and vascular changes while
reducing measurement corruption.

### Stage B: reference-condition estimation

For a feature vector (Y) and reference condition
(c\_{`\mathrm{ref}`{=tex}}):

\[ `\hat `{=tex}Y\_{c\_{`\mathrm{ref}`{=tex}}} = E`\left[
Y \mid X, do(C=c_{\mathrm{ref}})
\right]`{=tex}\]

Here (X) contains the observed history and relevant covariates. The
(do(`\cdot`{=tex})) notation expresses an intervention in a causal
model; it is not justified merely by fitting an ordinary regression.

In an observational dataset, the model may only estimate:

\[ E\[Y `\mid `{=tex}X, C=c\_{`\mathrm{ref}`{=tex}}\] \]

That conditional association is not automatically a causal
counterfactual. A causal interpretation requires defensible assumptions,
sufficient overlap, and an experimental design that addresses
confounding.

------------------------------------------------------------------------

## 6. Why an exact pure PPG is generally not identifiable

Suppose a person is walking and the PPG waveform is observed. The person
cannot simultaneously be sitting at the same instant with the same
underlying cardiovascular state. The sitting waveform is therefore
unobserved.

This is the fundamental counterfactual problem.

### Main reasons

1.  **Unobserved counterfactual:** only one activity condition is
    observed at a time.
2.  **Physiological interactions:** activity, temperature, posture,
    respiration, and autonomic state interact.
3.  **Latent state:** vascular tone, local perfusion, blood pressure,
    and autonomic regulation are not fully captured by common wearable
    sensors.
4.  **Non-unique mappings:** different physiological states can produce
    similar PPG features.
5.  **Sensor coupling:** contact pressure and movement can change the
    optical measurement and local tissue conditions simultaneously.
6.  **Lack of overlap:** the dataset may not contain comparable
    observations across contexts and covariate ranges.

### What can be estimated responsibly?

Prefer these targets, in increasing order of difficulty:

1.  Artifact probability or signal-quality score.
2.  Artifact-reduced pulse timing/heart-rate estimates.
3.  Artifact-reduced waveform, validated against an appropriate
    reference.
4.  Reference-condition feature distributions.
5.  Conditional expected reference-condition features with uncertainty.
6.  Full counterfactual waveform, only if a strong experimental design
    and validation support it.

A model should be allowed to say **"not identifiable / insufficient
support"** rather than invent a precise reference estimate.

------------------------------------------------------------------------

## 7. Reference condition: define the target precisely

Avoid the vague target "pure PPG." Define a reproducible reference
protocol.

### Candidate reference condition

**Awake, supine, resting, thermally stable, minimal movement, stable
sensor contact.**

Record:

-   Awake state, not sleep.
-   Supine posture.
-   Arm and sensor position.
-   Sensor model, location, and strap/contact condition.
-   Room/environmental temperature where possible.
-   Skin temperature.
-   Time since recent exercise.
-   Rest duration before recording.
-   ECG and respiration if available.

This is a *reference protocol*, not a claim that the person's physiology
is free of all influences.

### Why not simply use sleep?

Sleep includes changing sleep stages, autonomic states, circadian
effects, and sleep postures. It should be analyzed as its own context,
not treated as an ideal universal ground truth.

### Choose the target level

  -----------------------------------------------------------------------
  Target                  Definition              Recommendation
  ----------------------- ----------------------- -----------------------
  Reference feature       Expected pulse          Start here
  vector                  amplitude, width, rise  
                          time, etc. under        
                          reference protocol      

  Reference distribution  Prediction              Strongly recommended
                          interval/distribution   
                          for those features      

  Reference pulse         Average/median beat     Possible after quality
  template                morphology under        control
                          reference protocol      

  Full reference waveform Time-aligned waveform   Advanced; high risk of
                          under hypothetical      unsupported
                          reference condition     reconstruction
  -----------------------------------------------------------------------

The first practical target should be a reference-condition feature
vector and its uncertainty, not a full waveform.

------------------------------------------------------------------------

## 8. Proposed two-branch research architecture

### High-level flow

``` mermaid
flowchart TD
    A["Synchronized wearable data"] --> B["Time alignment and data audit"]
    B --> C["PPG preprocessing and signal-quality assessment"]
    C --> D["Branch A: artifact correction"]
    D --> E["Artifact-reduced observed PPG"]
    E --> F["Extract pulse and morphology features"]
    F --> G["Context and physiology model"]
    H["Activity, posture, temperature, ECG, respiration, EDA"] --> G
    G --> I["Branch B: reference-condition feature estimator"]
    I --> J["Predicted reference feature distribution"]
    J --> K["Uncertainty and support check"]
    K --> L["Validated estimate / insufficient support"]
```

### Branch A: artifact correction

``` mermaid
flowchart LR
    P["PPG"] --> Q["Quality assessment"]
    A["Accelerometer"] --> F["Motion reference features"]
    G["Gyroscope"] --> F
    C["Contact / sensor state"] --> Q
    Q --> M["Adaptive filter or learned model"]
    F --> M
    M --> O["Artifact-reduced PPG"]
    O --> V["Validate against ECG / reference PPG"]
```

### Branch B: reference-condition estimation

``` mermaid
flowchart TD
    P["Artifact-reduced PPG features"] --> F["Feature and history encoder"]
    C["Activity and posture history"] --> X["Context/physiology covariates"]
    T["Skin temperature"] --> X
    R["Respiration and ECG-derived features"] --> X
    X --> M["Conditional reference estimator"]
    F --> M
    M --> D["Reference feature distribution"]
    D --> U["Uncertainty + overlap/support check"]
    U --> O["Estimate or abstain"]
```

### Outputs must remain separate

  -----------------------------------------------------------------------
  Output                              Interpretation
  ----------------------------------- -----------------------------------
  `ppg_clean`                         Artifact-reduced estimate of
                                      observed PPG

  `quality_score`                     Confidence/quality of the
                                      measurement

  `context_features`                  Activity, posture, temperature,
                                      respiration, etc.

  `reference_features`                Estimated features under the
                                      defined reference condition

  `reference_uncertainty`             Prediction uncertainty

  `support_flag`                      Whether the model has enough
                                      relevant training support
  -----------------------------------------------------------------------

Do not label `reference_features` as measured PPG or "true clean PPG."

------------------------------------------------------------------------

## 9. Sensor fusion and covariates

### Recommended sensors

  -----------------------------------------------------------------------
  Sensor                  Main contribution       Limitation
  ----------------------- ----------------------- -----------------------
  PPG                     Primary optical pulse   Affected by motion,
                          measurement             contact, perfusion, and
                                                  device factors

  Accelerometer           Movement intensity and  Movement is not
                          motion reference        identical to artifact

  Gyroscope               Rotation/orientation    Does not directly
                          changes                 measure sensor-skin
                                                  coupling

  Skin temperature        Thermal/peripheral      Slow response; location
                          vascular context        matters

  ECG                     Independent cardiac     Does not directly
                          electrical timing       validate PPG amplitude
                                                  or morphology

  Respiration             Respiratory modulation  May be unavailable or
                                                  noisy in consumer
                                                  wearables

  EDA                     Arousal/sweating        Not a direct measure of
                          context                 vascular state

  Contact pressure        Sensor coupling         Often unavailable in
                                                  commercial devices
  -----------------------------------------------------------------------

### Sensor priority

For an initial study:

1.  PPG.
2.  Accelerometer.
3.  Gyroscope if available.
4.  Skin temperature.
5.  ECG for validation.
6.  Respiration if available.

EDA and contact pressure can be added when the device and protocol
support them.

### Important timing consideration

Signals may have different sampling rates. Align by timestamps and
account for sensor response time. Temperature changes are typically
slower than beat-level PPG changes; do not naively interpolate low-rate
temperature into a high-rate waveform and treat the interpolated samples
as new information.

------------------------------------------------------------------------

## 10. Data and experimental design

### 10.1 Existing 10-day observational dataset

Use the continuous dataset for:

-   Data quality audit.
-   Context coverage analysis.
-   Artifact detection.
-   Association analysis.
-   Feature extraction.
-   Initial predictive modeling.

Record how much valid data exists in each activity/posture context and
how many distinct episodes and days are represented.

Observational data alone cannot establish the exact same-time
counterfactual.

### 10.2 Controlled repeated-measures protocol

A supplementary experiment is strongly recommended.

For each participant, collect synchronized PPG, accelerometry, and
ideally ECG and skin temperature during:

1.  Awake supine rest.
2.  Seated rest.
3.  Standing still.
4.  Controlled walking at documented intensity.
5.  Recovery after walking.
6.  Repeated supine/seated reference sessions.

Repeat on multiple days. Standardize sensor placement and contact, arm
position, and protocol timing. Randomize condition order where practical
and allow recovery. Record environmental conditions and relevant
protocol events.

The reference protocol should be repeated before and after activity
where possible. This provides measured reference observations near the
activity block, although it still does not reveal the exact simultaneous
counterfactual.

### 10.3 Why repeated reference sessions matter

A reference session before activity and another after recovery can help
estimate:

-   Short-term repeatability.
-   Day-to-day drift.
-   Recovery dynamics.
-   Whether a model's reference estimate is systematically biased.
-   Whether temperature or other covariates explain differences between
    sessions.

Do not assume the pre-activity and post-activity reference measurements
are identical; physiological state may have changed.

### 10.4 Experimental controls

-   Same device and sensor site.
-   Documented strap fit/contact.
-   Consistent arm position.
-   Stable reference posture.
-   Recorded environmental and skin temperature.
-   ECG synchronization for cardiac timing.
-   Defined recovery period.
-   Repeated sessions across days.
-   Clear label and transition rules.

Ethics approval and informed consent are required where applicable.

------------------------------------------------------------------------

## 11. Modeling approaches

Develop in increasing complexity. Each model should answer a distinct
question.

### 11.1 Branch A: measurement artifact correction

**A. Quality-based rejection/weighting**

First establish a baseline that flags low-quality windows rather than
trying to reconstruct every corrupted segment. This is a meaningful
benchmark.

**B. Adaptive noise cancellation**

Use accelerometer/gyroscope channels as reference inputs. Adaptive
filters (e.g., LMS or RLS variants) can estimate components correlated
with the reference. Their key limitation is that movement references may
also correlate with real physiological responses.

**C. Signal decomposition**

Potential methods include wavelet transforms, empirical mode
decomposition, and time-frequency filtering. Evaluate whether morphology
and pulse timing are preserved.

**D. Supervised waveform reconstruction**

Possible architectures:

-   1D CNN / temporal convolutional network.
-   U-Net-like temporal model.
-   LSTM/GRU.
-   CNN + recurrent model.
-   Transformer, if data volume supports it.

Use a high-quality reference waveform collected simultaneously or during
a carefully controlled setup. A model trained only to predict a smoothed
version of its own corrupted input does not establish recovery of the
true pulse waveform.

### 11.2 Branch B: reference-condition feature estimation

Start with feature-level predictions:

\[ `\hat{\mathbf y}`{=tex}*{ref} = f*`\theta`{=tex}(
`\mathbf `{=tex}y\_{obs}, `\mathbf `{=tex}x\_{context},
`\mathbf `{=tex}x\_{physiology}, `\mathbf `{=tex}h\_{history} ) \]

where:

-   (`\mathbf `{=tex}y\_{obs}): observed artifact-reduced PPG feature
    vector.
-   (`\mathbf `{=tex}x\_{context}): activity and posture.
-   (`\mathbf `{=tex}x\_{physiology}): temperature, respiration,
    ECG-derived variables, etc.
-   (`\mathbf `{=tex}h\_{history}): recent physiological/context
    history.

Possible methods:

  -----------------------------------------------------------------------
  Method                  Strength                Limitation
  ----------------------- ----------------------- -----------------------
  Linear/robust           Interpretable baseline  Limited nonlinear
  regression                                      interactions

  Generalized additive    Smooth nonlinear        Requires careful
  model                   effects                 feature specification

  Mixed-effects model     Handles                 Needs multiple
                          participant-specific    participants/sessions
                          effects                 

  Random Forest /         Nonlinear tabular       Extrapolation can be
  gradient boosting       modeling                poor

  Conditional VAE         Models conditional      May generate plausible
                          distributions           but incorrect outputs

  Conditional diffusion   Flexible waveform       Data-hungry and
  model                   generation              difficult to validate

  Structural causal model Explicit assumptions    Requires defensible
                          and interventions       causal graph and
                                                  identification
                                                  assumptions
  -----------------------------------------------------------------------

### 11.3 Causal modeling

A causal graph should be specified before claiming that a model removes
the causal effect of activity.

An illustrative graph:

``` mermaid
flowchart TD
    A["Activity"] --> M["Movement artifact"]
    A --> H["Cardiovascular/autonomic response"]
    T["Temperature"] --> V["Peripheral vascular tone"]
    H --> V
    R["Respiration"] --> H
    S["Posture"] --> H
    S --> V
    M --> P["Observed PPG"]
    V --> P
    H --> P
    C["Sensor contact"] --> P
    D["Device properties"] --> P
```

This graph is only a starting hypothesis. The real causal structure may
include additional variables and feedback. For example, activity can
affect temperature and respiration, and these can affect peripheral
vascular state.

Potential confounders include:

-   Time of day/circadian phase.
-   Recent exercise and recovery.
-   Meals/caffeine.
-   Stress/arousal.
-   Medication.
-   Ambient temperature.
-   Illness.
-   Sensor fit and placement.

Do not adjust for every measured variable automatically. In causal
inference, conditioning on a mediator or collider can introduce bias.
Define the estimand and causal graph first.

------------------------------------------------------------------------

## 12. Training targets and loss functions

### 12.1 Branch A targets

Best case: a synchronized, high-quality reference PPG waveform measured
with a suitable reference sensor/setup.

Possible losses:

\[ L\_{`\mathrm{wave}`{=tex}} = `\frac{1}{N}`{=tex}`\sum`{=tex}*t
(P*{`\mathrm{pred}`{=tex}}(t)-P\_{`\mathrm{ref}`{=tex}}(t))\^2 \]

Additional terms may include:

-   Beat timing loss.
-   Pulse morphology loss.
-   Frequency-domain loss.
-   Robust loss for outliers.
-   Quality-aware weighting.

Do not optimize waveform MSE alone: a smoothed waveform can achieve low
error while losing sharp pulse morphology or timing information.

### 12.2 Branch B targets

Use measured reference-condition features from repeated controlled
sessions.

For a feature vector (`\mathbf `{=tex}y):

\[ L\_{`\mathrm{feature}`{=tex}} =
\|`\hat{\mathbf y}`{=tex}*{ref}-`\mathbf `{=tex}y*{ref}\|\_1 \]

or a suitable robust loss.

For probabilistic predictions, evaluate negative log-likelihood or
proper scoring rules and check prediction interval coverage.

### 12.3 Uncertainty and abstention

The model should return:

\[ (`\hat{\mathbf y}`{=tex}*{ref}, `\Sigma`{=tex}*{ref}, s) \]

where:

-   (`\hat{\mathbf y}`{=tex}\_{ref}): predicted reference feature
    vector.
-   (`\Sigma`{=tex}\_{ref}): uncertainty or covariance estimate.
-   (s): support/overlap indicator.

Use conformal prediction, quantile regression, ensembles, or Bayesian
approaches as appropriate. Calibration must be evaluated on held-out
sessions/days. If the observed context lies outside the training
distribution, the model should flag the estimate as unsupported.

### 12.4 Avoid target leakage

If the model is given ECG-derived heart rate as an input, it cannot
fairly be evaluated as an independent PPG heart-rate estimator against
that same ECG measurement. ECG can be used as a reference target, a
covariate for a distinct estimand, or both in separate experiments---but
the roles must be explicit.

------------------------------------------------------------------------

## 13. Validation strategy

### Branch A: artifact correction

Evaluate:

-   Pulse detection sensitivity and positive predictive value against
    ECG.
-   Heart-rate MAE/RMSE against ECG-derived heart rate.
-   Beat-to-beat interval error.
-   Waveform correlation/error against an appropriate high-quality PPG
    reference.
-   Signal-quality improvement.
-   Performance stratified by activity and signal quality.

Caveats:

-   ECG R-R intervals and PPG pulse intervals are not identical because
    of pulse transit and vascular effects.
-   ECG validates electrical timing/heart rate, not PPG amplitude or
    morphology.
-   A signal-quality score is not a substitute for reference waveform
    validation.

### Branch B: reference-condition estimation

Evaluate:

-   Feature MAE/RMSE against held-out measured reference sessions.
-   Prediction interval coverage and width.
-   Bias by activity, posture, temperature, and time of day.
-   Within-person repeatability.
-   Calibration across days.
-   Performance for each feature separately.
-   Support/abstention rate.

### Required comparison models

1.  Raw PPG with no correction.
2.  Quality rejection only.
3.  PPG + accelerometer artifact correction.
4.  PPG + accelerometer + gyroscope.
5.  Artifact-corrected PPG + context covariates.
6.  Full multimodal reference-feature estimator.

Ablation studies should remove one sensor group at a time to quantify
incremental value.

### Data splitting

-   Split by participant where population generalization is claimed.
-   Split by day/session for longitudinal personalization.
-   Keep adjacent/overlapping windows from the same episode in one
    partition.
-   Fit preprocessing/scalers only on training data.
-   Do not use future observations to construct a baseline for
    prospective evaluation.
-   Evaluate chronological calibration and future-day performance.

------------------------------------------------------------------------

## 14. Recommended experiments

### Experiment 1 --- Motion artifact correction benchmark

**Question:** Does accelerometer-assisted correction improve pulse
timing and waveform quality compared with quality rejection alone?

Compare: - Quality rejection. - Adaptive filtering. - A supervised
temporal model, if reference data exist.

Primary evaluation: ECG-based pulse-rate error and reference-waveform
metrics where available.

### Experiment 2 --- Context and temperature association

**Question:** Do posture, temperature, respiration, and activity explain
additional PPG feature variation after quality control?

Use interpretable regression/mixed-effects models first. Report
associations, not causal effects, unless the design supports causal
identification.

### Experiment 3 --- Reference-feature prediction

**Question:** Can the model predict selected PPG features measured
during a standardized reference protocol from observations in other
conditions?

Use repeated reference sessions and held-out days. Predict feature
distributions, not only point estimates.

### Experiment 4 --- Generalization and abstention

**Question:** When does the estimator become unreliable?

Test: - Unseen activity intensity. - Unseen temperature ranges. -
Different days. - Sensor refitting. - Low-quality windows. - Missing
modalities.

Report when the model abstains.

### Experiment 5 --- Full waveform reconstruction (optional advanced study)

Only proceed if: - A suitable waveform target exists. - Time alignment
is reliable. - The model preserves beat timing and morphology. -
Independent validation shows more than visual smoothness.

A generated waveform should never be presented as a directly measured
waveform.

------------------------------------------------------------------------

## 15. Datasets and resources

### PPG-DaLiA

A useful starting point for PPG plus motion and ECG-based validation.

-   15 participants.
-   Wrist BVP/PPG, accelerometer, EDA, and temperature.
-   Chest ECG, respiration, and accelerometer.
-   Daily activity protocol.

Links: - [UCI
dataset](https://archive.ics.uci.edu/dataset/495/ppg+dalia) - [Original
project page](https://kristofvl.github.io/usi/data_ppgdalia.html) -
[Deep PPG paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC6679242/)

Limitations: It is not a complete controlled dataset for sleep,
standing, and all reference-state comparisons.

### WESAD

Useful for multimodal physiological context, especially stress/affect:

-   BVP.
-   ECG.
-   Accelerometry.
-   Temperature.
-   EDA.
-   Respiration.
-   Additional signals.

[WESAD dataset
page](https://ubicomp.eti.uni-siegen.de/home/datasets/icmi18/)

### WildPPG

A naturalistic PPG resource with multiple contexts and wearable
measurements. Review its protocol, sensor availability, and license
before use.

[WildPPG preprint](https://arxiv.org/abs/2412.17540)

### GalaxyPPG

A multimodal wearable PPG dataset with synchronized wearable
measurements. Review its participant protocol and exact sensor fields
before designing an experiment.

[GalaxyPPG paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC12119839/)

### Controlled study

Public datasets may not contain the repeated, controlled reference
measurements needed for a counterfactual claim. A small supplementary
study may be essential.

------------------------------------------------------------------------

## 16. Limitations and threats to validity

1.  **Counterfactual non-identifiability:** the same person cannot be
    observed simultaneously in two activity states.
2.  **Unmeasured confounding:** latent vascular/autonomic state may
    affect both context and PPG.
3.  **Physiology is not noise:** exercise, posture, temperature, and
    respiration cause real physiological changes.
4.  **Artifact/physiology overlap:** movement can affect both sensor
    coupling and cardiovascular state.
5.  **Reference protocol variation:** supine rest itself varies with
    time, temperature, recovery, and autonomic state.
6.  **ECG limitations:** ECG validates cardiac electrical timing, not
    all PPG morphology.
7.  **Device dependence:** models may fail across devices, wavelengths,
    sensor sites, firmware, or strap fits.
8.  **Population generalization:** one participant's 10-day data cannot
    establish a population-level model.
9.  **Temporal leakage:** adjacent windows and repeated episodes can
    make random splits deceptively optimistic.
10. **Generative hallucination:** a plausible waveform is not proof of a
    physiologically correct waveform.
11. **Over-normalization:** reducing variance can remove real
    cardiovascular responses.
12. **Uncertainty miscalibration:** model confidence may be unreliable
    outside the training distribution.

------------------------------------------------------------------------

## 17. Suggested implementation plan

### Milestone 1 --- Dataset audit

-   [ ] Inventory sensors and sampling rates.
-   [ ] Verify timestamps and synchronization.
-   [ ] Inspect representative raw PPG windows.
-   [ ] Quantify missingness and clipping.
-   [ ] Determine available activity/posture labels.
-   [ ] Identify ECG reference availability.

### Milestone 2 --- Artifact correction baseline

-   [ ] Implement quality flags and window rejection.
-   [ ] Implement a simple pulse detector.
-   [ ] Establish ECG-based heart-rate benchmark.
-   [ ] Add accelerometer features.
-   [ ] Test adaptive filtering where appropriate.
-   [ ] Report performance by activity and quality.

### Milestone 3 --- Context association model

-   [ ] Extract PPG features.
-   [ ] Align activity, posture, and temperature.
-   [ ] Fit interpretable regression models.
-   [ ] Analyze within-person and between-day effects.
-   [ ] Perform sensor ablations.

### Milestone 4 --- Reference protocol

-   [ ] Define awake supine resting protocol.
-   [ ] Standardize sensor placement and arm position.
-   [ ] Record ECG and temperature if possible.
-   [ ] Repeat sessions across days.
-   [ ] Document recovery and environmental conditions.

### Milestone 5 --- Reference-feature estimator

-   [ ] Define exact estimand and feature targets.
-   [ ] Establish covariate/causal diagram.
-   [ ] Check covariate overlap and support.
-   [ ] Train a simple conditional model.
-   [ ] Add prediction intervals.
-   [ ] Evaluate on held-out sessions/days.
-   [ ] Implement abstention for unsupported inputs.

### Milestone 6 --- Optional waveform model

-   [ ] Confirm high-quality waveform targets exist.
-   [ ] Verify alignment.
-   [ ] Train a compact temporal model.
-   [ ] Evaluate timing and morphology preservation.
-   [ ] Compare against simple interpolation/filtering baselines.
-   [ ] Report uncertainty and failure cases.

------------------------------------------------------------------------

## 18. Suggested repository structure

``` text
ppg-context-normalization/
├── README.md
├── LICENSE
├── CITATION.cff
├── requirements.txt
├── configs/
│   ├── device.yaml
│   ├── preprocessing.yaml
│   ├── artifact_model.yaml
│   ├── reference_protocol.yaml
│   └── normalization_model.yaml
├── data/
│   ├── README.md
│   ├── raw/                 # Private; never commit
│   ├── interim/
│   └── processed/
├── docs/
│   ├── estimand_and_assumptions.md
│   ├── causal_diagram.md
│   ├── reference_protocol.md
│   ├── feature_definitions.md
│   └── validation_plan.md
├── notebooks/
│   ├── 01_data_audit.ipynb
│   ├── 02_synchronization.ipynb
│   ├── 03_signal_quality.ipynb
│   ├── 04_artifact_correction.ipynb
│   ├── 05_context_associations.ipynb
│   ├── 06_reference_features.ipynb
│   └── 07_uncertainty_and_validation.ipynb
├── src/
│   ├── io/
│   ├── synchronization/
│   ├── preprocessing/
│   ├── quality/
│   ├── artifact_removal/
│   ├── context/
│   ├── features/
│   ├── causal/
│   ├── normalization/
│   └── evaluation/
├── tests/
├── results/
│   ├── figures/
│   └── tables/
└── assets/
    ├── two_outputs.svg
    └── architecture.svg
```

Suggested `.gitignore`:

``` gitignore
data/raw/
data/interim/
data/processed/
results/
*.pkl
*.mat
*.h5
*.hdf5
*.parquet
.ipynb_checkpoints/
__pycache__/
.venv/
.env
```

Do not publish identifiable physiological recordings without the
required consent, ethics approval, and data-sharing permissions.

------------------------------------------------------------------------

## 19. Research papers and reading list

The following papers support the background and methods. They do not all
directly solve reference-state counterfactual PPG estimation; that is
the research gap being investigated.

### A. PPG and motion artifact removal

1.  **Wearable Photoplethysmography for Cardiovascular Monitoring
    (2020).**
    -   Broad wearable PPG review, including motion artifacts, sensors,
        and cardiovascular applications.
    -   [Full text
        (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC7612541/)
2.  **Ismail, Akram & Siddiqi (2021). Heart rate tracking in
    photoplethysmography signals affected by motion artifacts: a
    review.**
    -   Reviews adaptive filtering, multiresolution techniques, and
        motion-affected PPG analysis.
    -   [Springer](https://link.springer.com/article/10.1186/s13634-020-00714-2)
3.  **Deep PPG: Large-Scale Heart Rate Estimation with Convolutional
    Neural Networks (2019).**
    -   Uses PPG-DaLiA and synchronized motion information for
        heart-rate estimation.
    -   [Full text
        (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC6679242/)
    -   [DOI](https://doi.org/10.3390/s19143079)
4.  **Machine Learning Applied to Reference Signal-Less Detection of
    Motion Artifacts in Photoplethysmographic Signals: A Review.**
    -   Reviews machine learning for detecting PPG motion artifacts
        without a separate measured reference signal.
    -   [Full text
        (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC11598458/)

### B. Physiological and environmental influences

5.  **An Experimental Study of the Effects of External Physiological
    Parameters on the Photoplethysmography Signals in the Context of
    Local Blood Pressure (2017).**
    -   Explores posture, hydrostatic pressure, respiration, and other
        influences.
    -   [Full text
        (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC5375842/)
    -   [DOI](https://doi.org/10.3390/s17030556)
6.  **Determinants of photoplethysmography signal quality at the wrist
    (2025).**
    -   Investigates posture and sensor height as determinants of wrist
        PPG quality.
    -   [Full text
        (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC12204546/)
    -   [DOI](https://doi.org/10.1371/journal.pdig.0000585)
    -   [Analysis
        code](https://github.com/peterhcharlton/PPG_quality_determinants)
7.  **Insights into vascular physiology from sleep photoplethysmography
    (2023).**
    -   Explains why sleep is not one uniform physiological reference.
    -   [PubMed](https://pubmed.ncbi.nlm.nih.gov/37379483/)
8.  **Differential sensitivity of impedance plethysmography and
    photoplethysmography sensors to temperature-induced peripheral
    vasoconstriction (2026).**
    -   Relevant to thermal influences on peripheral PPG amplitude.
    -   [Scientific
        Reports](https://www.nature.com/articles/s41598-026-36563-6)

### C. Multimodal wearable datasets

9.  **WESAD: A Multimodal Dataset for Wearable Stress and Affect
    Detection.**
    -   Useful for stress, EDA, temperature, ECG, respiration, and BVP
        context.
    -   [Dataset
        page](https://ubicomp.eti.uni-siegen.de/home/datasets/icmi18/)
10. **WildPPG (2024 preprint).**
    -   Naturalistic PPG data and wearable context.
    -   [arXiv](https://arxiv.org/abs/2412.17540)
11. **GalaxyPPG (2025).**
    -   Multimodal wearable PPG dataset.
    -   [Full text
        (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC12119839/)

### D. Causal inference foundations

12. **Hernán & Robins. Causal Inference: What If.**
    -   Foundational treatment of potential outcomes, interventions,
        confounding, and causal estimands.
    -   [Free online
        book](https://www.hsph.harvard.edu/miguel-hernan/causal-inference-book/)
13. **Pearl, Glymour & Jewell. Causal Inference in Statistics: A
    Primer.**
    -   Useful introduction to causal graphs and intervention-based
        reasoning.
    -   [Book
        information](https://www.wiley.com/en-us/Causal+Inference+in+Statistics%3A+A+Primer-p-9781119186847)

### Recommended reading order

1.  Read papers 1--3 to understand PPG artifact correction.
2.  Read papers 5--8 to understand why context changes PPG
    physiologically.
3.  Explore PPG-DaLiA and WESAD to understand synchronized sensor data.
4.  Read Hernán & Robins before making counterfactual or causal claims.
5.  Define the reference-condition estimand before selecting a
    generative architecture.

------------------------------------------------------------------------

## 20. Reporting checklist

-   [ ] State whether the result is artifact correction or
    reference-condition estimation.
-   [ ] Define the reference condition and target features.
-   [ ] Describe device, wavelength, sensor site, sampling rate, and
    firmware.
-   [ ] Describe all synchronized signals and alignment.
-   [ ] Specify activity/posture labels and confidence.
-   [ ] Document filtering, segmentation, and quality criteria.
-   [ ] Define artifact reference/ground truth.
-   [ ] Define causal graph and assumptions if making causal claims.
-   [ ] Report overlap/positivity across contexts and covariates.
-   [ ] Report missing data and unsupported cases.
-   [ ] Use participant/session/day-level splits.
-   [ ] Prevent temporal and feature leakage.
-   [ ] Report feature-level error and uncertainty.
-   [ ] Validate ECG-derived timing separately from PPG morphology.
-   [ ] Report failure cases and abstention.
-   [ ] Share code/configuration where permitted.
-   [ ] Follow ethics, consent, privacy, and data-license requirements.

------------------------------------------------------------------------

## 21. Glossary

  -----------------------------------------------------------------------
  Term                                Definition
  ----------------------------------- -----------------------------------
  PPG                                 Photoplethysmography

  BVP                                 Blood volume pulse, often used as a
                                      wearable PPG signal label

  Motion artifact                     Measurement distortion associated
                                      with movement

  Physiological response              Genuine change in
                                      cardiovascular/autonomic function

  Reference condition                 Precisely defined protocol used as
                                      a target condition

  Counterfactual                      Outcome that would occur under an
                                      alternative intervention/condition

  Estimand                            Precisely defined quantity a study
                                      aims to estimate

  Confounding                         A common cause of exposure/context
                                      and outcome

  Positivity/overlap                  Availability of relevant
                                      observations across
                                      covariate/context combinations

  SQI                                 Signal-quality index

  ECG                                 Electrocardiogram

  PRV                                 Pulse-rate variability from pulse
                                      intervals

  HRV                                 Heart-rate variability,
                                      conventionally measured from ECG
                                      R-R intervals

  Uncertainty calibration             Agreement between predicted
                                      uncertainty/intervals and observed
                                      errors

  Abstention                          Model declines to provide an
                                      estimate when support or quality is
                                      inadequate
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## 22. Research boundaries and safety note

This repository describes a research framework, not a validated medical
device. A predicted reference-state feature is not a directly measured
physiological value and must not be used as a diagnosis.

The central scientific rule is:

> **Correct measurement artifacts without erasing real physiology.
> Estimate reference-condition features only after defining the target,
> assumptions, and validation protocol.**

A clean-looking waveform is not proof of a correct waveform. A
low-variance output is not proof of successful normalization. A model
should preserve meaningful physiological information, quantify
uncertainty, and abstain when the data do not support a reliable
estimate.

### Suggested first milestone

Start with a small, interpretable study:

1.  Audit the 10-day PPG and all available synchronized signals.
2.  Compare quality rejection with accelerometer-assisted artifact
    correction.
3.  Validate pulse timing against ECG if available.
4.  Quantify how posture, temperature, and activity relate to selected
    PPG features.
5.  Define an awake supine reference protocol.
6.  Collect repeated reference sessions if possible.
7.  Predict only a few reference-condition features, report uncertainty,
    and evaluate on held-out days/sessions.

This sequence creates evidence for each stage before attempting
full-waveform counterfactual reconstruction.
